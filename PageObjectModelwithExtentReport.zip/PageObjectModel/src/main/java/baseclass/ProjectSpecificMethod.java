package baseclass;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import utils.ReadExcelData;



public class ProjectSpecificMethod {
	public RemoteWebDriver driver;
	public String filename;
	public static ExtentReports extent;
	public ExtentTest createTest,createNode;
	public String testName,testDesc,author,category;
	
	@Parameters({"url"})
	@BeforeMethod
	public void preConditions(String url) {
		createNode = createTest.createNode(testName);
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			}
	@AfterMethod
	public void postCondition() {
		driver.close();
	}	
	@BeforeSuite
	public void startreport() {
		ExtentHtmlReporter reporter=new ExtentHtmlReporter("./reports/result.html");
		reporter.setAppendExisting(true);
		extent =new ExtentReports();
		extent.attachReporter(reporter);
	}
	
	@BeforeClass
	public void testcaseDetails() {
		createTest = extent.createTest(testName, testDesc);
		createTest.assignAuthor(author);
		createTest.assignCategory(category);
	}	
	public void reportStep(String status,String message) throws IOException {		
		if(status.equalsIgnoreCase("pass")) {
			createNode.pass(message,MediaEntityBuilder.createScreenCaptureFromPath(".././snap/shot" + takeSnap() + ".png").build());
		}
		else if(status.equalsIgnoreCase("fail")){
			createNode.fail(message,MediaEntityBuilder.createScreenCaptureFromPath(".././snap/shot" + takeSnap() + ".png").build());
			throw new RuntimeException();
		}	}	
	
	public int takeSnap() throws IOException {
		int random = (int) (Math.random() * 999999);
		File screenshotAs = driver.getScreenshotAs(OutputType.FILE);
		File destn = new File("./snap/shot" + random + ".png");
		FileUtils.copyFile(screenshotAs, destn);
		return random;

	}	
	
	@AfterSuite
	public void endReport() {
		extent.flush();
	}
		
	  @DataProvider(name="fetchData")
	  public String[][] sendData() throws IOException {
	  
	    	  return ReadExcelData.readData(filename);
	  
	  }
	 

}
