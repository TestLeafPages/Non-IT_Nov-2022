package baseclass;

import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {

	public static void main(String[] args) throws IOException {

		//Step:1 Setting the file path
		ExtentHtmlReporter reporter=new ExtentHtmlReporter("./reports/result.html");
		
		//to have history of the result/report
		reporter.setAppendExisting(true);
		//to get the actual data 
		ExtentReports extent =new ExtentReports();
		
		//attach the actual data to result.html
		extent.attachReporter(reporter);
		
		
		//to report the required testcase
		
		ExtentTest createTest = extent.createTest("Login testcase","Validating the Positive functionality");
		createTest.assignCategory("Regression");
		createTest.assignAuthor("Catherine");
		
		//to get the status
		createTest.pass("Test is passed");
		createTest.fail("Testcase is failed");
		//to assign category of the test
		
		
		
		ExtentTest cTest = extent.createTest("CreateLead testcase","Validating the Positive functionality");

		cTest.assignCategory("Smoke");
		cTest.assignAuthor("Meera");
		
		//to get the status
		cTest.pass("Testcase is passed",MediaEntityBuilder.createScreenCaptureFromPath(".././snap/pic2.jpg").build());
		cTest.fail("Testcase is failed",MediaEntityBuilder.createScreenCaptureFromPath(".././snap/pic2.jpg").build());
		//to assign category of the test
		
		
		int random =   (int) (Math.random()*999999);
		System.out.println(random);
		
		//mandatory step
		extent.flush();
		
	}

}
