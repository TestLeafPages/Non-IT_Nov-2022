package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import baseclass.ProjectSpecificMethod;
import pages.LoginPage;


public class LoginTc extends ProjectSpecificMethod {

	@BeforeTest
	public void setfile() {
		filename="Logindata";
		testName="Login TestCase";
		testDesc="Positive funtionality of login Page";
		author="Niveda";
		category="Funtional";
	}
	//BeforeTest, BeforeClass
	
	
	@Test(dataProvider="fetchData")
	public void runLogin(String uname, String pwd) throws IOException {
		
		//LoginPage lp=new LoginPage();
		new LoginPage(driver, createNode)
		.enterUsername(uname)
		.enterPassword(pwd)
		.clickLogin()
		.clickCrmsfa()
		.verifyHomePage();
		
		/*
		 * lp.enterPassword(); lp.clickLogin();
		 * 
		 * WelcomePage wp =new WelcomePage(); wp.clickCrmsfa();
	 */
		
	}
	
}
