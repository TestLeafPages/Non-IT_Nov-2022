package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import baseclass.ProjectSpecificMethod;
import pages.LoginPage;


public class CreateLeadTC extends ProjectSpecificMethod {

	
	@BeforeTest
	public void setfile() {
		filename="CreateLead";
		testName="CreateLead";
		testDesc="Create the Lead with mandatory Data";
		author="Niveda";
		category="Funtional";
	}
	
	
	@Test(dataProvider="fetchData")
	public void runCreate(String uname,String pwd,String cname, String fname, String lname,String phno) throws IOException {
		
		//LoginPage lp=new LoginPage();
		new LoginPage(driver,createNode)
		.enterUsername(uname)
		.enterPassword(pwd)
		.clickLogin()
		.clickCrmsfa()
		.verifyHomePage()
		.clickLeads()
		.clickCreateLead()
		.enterCompanyname(cname)
		.enterFirstname(fname)
		.enterLastname(lname)
		.enterPhoneNumber(phno)
		.clickCreatelead()
		.verifyViewLead();
		
	
		
	}
	
}
