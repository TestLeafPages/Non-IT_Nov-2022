package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import baseclass.ProjectSpecificMethod;

public class ViewLeadPage extends ProjectSpecificMethod{

	public ViewLeadPage(RemoteWebDriver driver, ExtentTest createNode) {
		this.driver=driver;
		this.createNode=createNode;
	}

	public ViewLeadPage verifyViewLead() {
		System.out.println(driver.getTitle());
		return this;
	}
	
}
