package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import baseclass.ProjectSpecificMethod;

public class LoginPage extends ProjectSpecificMethod {

	public LoginPage(RemoteWebDriver driver,ExtentTest createNode) {
     this.createNode=createNode;
		this.driver = driver;
	}

	public LoginPage enterUsername(String uname) throws IOException {
		try {
			driver.findElement(By.id("username")).sendKeys(uname);
			reportStep("Pass", "Username is entered Successfully");
		} catch (Exception e) {
			reportStep("Fail", "Username is not entered Successfully " + e);
		}

		return this;
	}

	public LoginPage enterPassword(String pwd) throws IOException {
		try {
			driver.findElement(By.id("password")).sendKeys(pwd);
			reportStep("Pass", "Password is entered Successfully");

		} catch (Exception e) {
			reportStep("Fail", "Password is not entered Successfully" + e);
		}
		return this;
	}

	public WelcomePage clickLogin() throws IOException {
		try {
			driver.findElement(By.className("decorativeSubmit")).click();
			reportStep("Pass", "Login button is Clicked Successfully");
		} catch (Exception e) {
			reportStep("Fail", "Login button is not clicked successfully " + e);

		}
		return new WelcomePage(driver,createNode);
	}

}
