package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import baseclass.ProjectSpecificMethod;

public class LeadsPage extends ProjectSpecificMethod{
	
	public LeadsPage(RemoteWebDriver driver, ExtentTest createNode) {
		this.driver=driver;
		this.createNode=createNode;
	}
	
	
	public CreateLeadPage clickCreateLead() {
		driver.findElement(By.linkText("Create Lead")).click();
		return new CreateLeadPage(driver,createNode);
	}
	
	public CreateLeadPage clickFindLead() {
		//driver.findElement(By.linkText("Create Lead")).click();
		return new CreateLeadPage(driver,createNode);
	}
	
}
